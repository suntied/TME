baseUrl = 'http://51.255.166.155:1352/tig/'

####################
#...TME2 starts....#
randomImageUrl = ['https://image.freepik.com/vecteurs-libre/poisson_53876-59060.jpg',
            'https://image.freepik.com/photos-gratuite/poisson-frais-blanc_144627-24519.jpg',
            'https://image.freepik.com/vecteurs-libre/ingredients-cocktail-fruits-mer-composition-realiste-crevettes-poisson-saumon-frais-entieres-tentacule-poulpe-herbes-citron_1284-31931.jpg',
            'https://image.freepik.com/photos-gratuite/poisson-cru-marche_1398-2421.jpg',
            'https://image.freepik.com/vecteurs-libre/steaks-crus-poisson-saumon-jeu-icones-caviar-isole-blanc_1284-33354.jpg',
            'https://image.freepik.com/photos-gratuite/produits-marins-crus-frais_1398-4262.jpg'
           ]
#...end of TME2....#
####################
